import { useEffect, useState } from "react";
import { uploadResume, getResumes, getResume, applyRewrites } from "./api";

const Bar = ({ label, value }) => (
  <div className="mb-2">
    <div className="flex justify-between text-sm">
      <span className="capitalize">{label}</span>
      <span>{value}</span>
    </div>
    <div className="h-2 rounded bg-gray-200">
      <div className="h-2 rounded bg-indigo-600" style={{ width: `${value}%` }} />
    </div>
  </div>
);

const sevColor = {
  high: "bg-red-100 text-red-700",
  medium: "bg-yellow-100 text-yellow-700",
  low: "bg-blue-100 text-blue-700",
};

export default function App() {
  const [resumes, setResumes] = useState([]);
  const [current, setCurrent] = useState(null);
  const [vIndex, setVIndex] = useState(0);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const loadList = () => getResumes().then(setResumes).catch(() => {});
  useEffect(() => {
    loadList();
  }, []);

  const show = (resume) => {
    setCurrent(resume);
    setVIndex(resume.versions.length - 1);
  };

  const run = async (fn) => {
    setLoading(true);
    setError("");
    try {
      show(await fn());
      loadList();
    } catch (e) {
      setError(e.response?.data?.message || e.message);
    } finally {
      setLoading(false);
    }
  };

  const version = current?.versions[vIndex];
  const a = version?.analysis;

  return (
    <div className="mx-auto max-w-5xl p-6">
      <h1 className="mb-6 text-3xl font-bold">AI Resume Checker</h1>

      <label className="block cursor-pointer rounded-xl border-2 border-dashed p-8 text-center hover:bg-gray-50">
        <input
          type="file"
          accept="application/pdf"
          className="hidden"
          onChange={(e) => {
            const f = e.target.files[0];
            e.target.value = "";
            if (f) run(() => uploadResume(f));
          }}
        />
        {loading
          ? "Analyzing with AI… (10-20s)"
          : "Click to upload your resume (PDF, max 5MB)"}
      </label>
      {error && <p className="mt-3 text-red-600">{error}</p>}

      {resumes.length > 0 && (
        <div className="mt-6 flex flex-wrap gap-2">
          <span className="text-sm text-gray-500">History:</span>
          {resumes.map((r) => (
            <button
              key={r._id}
              onClick={() => getResume(r._id).then(show)}
              className="rounded bg-gray-100 px-3 py-1 text-sm hover:bg-gray-200"
            >
              {r.filename}
            </button>
          ))}
        </div>
      )}

      {a && (
        <div className="mt-8 space-y-6">
          <div className="flex flex-wrap gap-2">
            {current.versions.map((v, i) => (
              <button
                key={i}
                onClick={() => setVIndex(i)}
                className={`rounded px-3 py-1 text-sm ${
                  i === vIndex ? "bg-indigo-600 text-white" : "bg-gray-100"
                }`}
              >
                V{v.versionNumber} · {v.analysis.atsScore}
              </button>
            ))}
          </div>

          <div className="grid gap-6 md:grid-cols-3">
            <div className="rounded-xl border p-6 text-center">
              <div className="text-6xl font-bold text-indigo-600">{a.atsScore}</div>
              <div className="text-gray-500">ATS Score</div>
            </div>
            <div className="rounded-xl border p-6 md:col-span-2">
              {Object.entries(a.breakdown).map(([k, v]) => (
                <Bar key={k} label={k} value={v} />
              ))}
            </div>
          </div>

          <div className="grid gap-6 md:grid-cols-2">
            <div className="rounded-xl border p-6">
              <h2 className="mb-3 text-xl font-semibold">Issues</h2>
              {a.issues.map((i, n) => (
                <div key={n} className="mb-3">
                  <span
                    className={`mr-2 rounded px-2 py-0.5 text-xs ${
                      sevColor[i.severity] || sevColor.low
                    }`}
                  >
                    {i.severity}
                  </span>
                  <b>{i.title}</b>
                  <p className="text-sm text-gray-600">{i.fix}</p>
                </div>
              ))}
            </div>
            <div className="rounded-xl border p-6">
              <h2 className="mb-3 text-xl font-semibold">Strengths</h2>
              <ul className="list-disc space-y-2 pl-5 text-sm">
                {a.strengths.map((s, n) => (
                  <li key={n}>{s}</li>
                ))}
              </ul>
            </div>
          </div>

          <div className="rounded-xl border p-6">
            <h2 className="mb-3 text-xl font-semibold">Keywords</h2>
            <p className="mb-1 text-xs text-gray-500">Present</p>
            <div className="mb-3 flex flex-wrap gap-2">
              {a.keywords.present.map((k) => (
                <span key={k} className="rounded bg-green-100 px-2 py-1 text-xs text-green-700">
                  {k}
                </span>
              ))}
            </div>
            <p className="mb-1 text-xs text-gray-500">Missing</p>
            <div className="flex flex-wrap gap-2">
              {a.keywords.missing.map((k) => (
                <span key={k} className="rounded bg-red-100 px-2 py-1 text-xs text-red-700">
                  {k}
                </span>
              ))}
            </div>
          </div>

          <div className="rounded-xl border p-6">
            <div className="mb-3 flex items-center justify-between">
              <h2 className="text-xl font-semibold">AI Bullet Rewrites</h2>
              {vIndex === current.versions.length - 1 && (
                <button
                  disabled={loading}
                  onClick={() => run(() => applyRewrites(current._id))}
                  className="rounded bg-indigo-600 px-4 py-2 text-sm text-white disabled:opacity-50"
                >
                  {loading ? "Working…" : "Apply all → new version"}
                </button>
              )}
            </div>
            {a.rewrites.map((r, n) => (
              <div key={n} className="mb-4 text-sm">
                <p className="text-red-600 line-through">{r.original}</p>
                <p className="text-green-700">{r.improved}</p>
                <p className="text-gray-500">Why: {r.reason}</p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
