import axios from "axios";

const api = axios.create({ baseURL: "http://localhost:5000/api" });

export const uploadResume = (file) => {
  const fd = new FormData();
  fd.append("resume", file);
  return api.post("/resumes", fd).then((r) => r.data);
};

export const getResumes = () => api.get("/resumes").then((r) => r.data);
export const getResume = (id) => api.get(`/resumes/${id}`).then((r) => r.data);
export const applyRewrites = (id, indexes) =>
  api.post(`/resumes/${id}/apply-rewrites`, { indexes }).then((r) => r.data);
