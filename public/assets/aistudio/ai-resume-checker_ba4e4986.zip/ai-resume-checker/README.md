# AI Resume Checker (MERN + Gemini)

## 1. Backend
    cd backend
    npm install
Edit `backend/.env`: set `MONGO_URI` and `GEMINI_API_KEY`
(key: https://aistudio.google.com/apikey).

    npm run dev      # http://localhost:5000

## 2. Frontend (new terminal)
    cd frontend
    npm install
    npm run dev      # http://localhost:5173

Open http://localhost:5173 and upload a PDF resume.

Troubleshooting: Gemini 404 -> change GEMINI_MODEL in .env.
CORS error -> CLIENT_URL must equal your Vite URL.
