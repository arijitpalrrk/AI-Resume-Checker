import mongoose from "mongoose";

const versionSchema = new mongoose.Schema({
  versionNumber: Number,
  text: String,
  source: { type: String, default: "upload" }, // "upload" | "rewrite"
  analysis: Object,
  createdAt: { type: Date, default: Date.now },
});

const resumeSchema = new mongoose.Schema(
  {
    filename: String,
    versions: [versionSchema],
  },
  { timestamps: true }
);

export default mongoose.model("Resume", resumeSchema);
