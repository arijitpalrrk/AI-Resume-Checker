import { Router } from "express";
import multer from "multer";
import pdf from "pdf-parse/lib/pdf-parse.js";
import Resume from "../models/Resume.js";
import { analyzeResume } from "../services/gemini.js";

const router = Router();

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter: (req, file, cb) =>
    file.mimetype === "application/pdf"
      ? cb(null, true)
      : cb(new Error("Only PDF files are allowed")),
});

// Upload a resume -> creates V1
router.post("/", (req, res) => {
  upload.single("resume")(req, res, async (uploadErr) => {
    try {
      if (uploadErr) return res.status(400).json({ message: uploadErr.message });
      if (!req.file) return res.status(400).json({ message: "No file uploaded" });

      const { text } = await pdf(req.file.buffer);
      if (!text || text.trim().length < 50)
        return res
          .status(400)
          .json({ message: "Could not read text. Is this a scanned PDF?" });

      const analysis = await analyzeResume(text);

      const resume = await Resume.create({
        filename: req.file.originalname,
        versions: [{ versionNumber: 1, text, source: "upload", analysis }],
      });

      res.status(201).json(resume);
    } catch (err) {
      console.error(err);
      res.status(500).json({ message: err.message });
    }
  });
});

// List all resumes
router.get("/", async (req, res) => {
  try {
    const resumes = await Resume.find()
      .sort({ updatedAt: -1 })
      .select("-versions.text");
    res.json(resumes);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Get one resume with all versions
router.get("/:id", async (req, res) => {
  try {
    const resume = await Resume.findById(req.params.id);
    if (!resume) return res.status(404).json({ message: "Not found" });
    res.json(resume);
  } catch (err) {
    res.status(400).json({ message: "Invalid id" });
  }
});

// Apply rewrites -> creates a new version
router.post("/:id/apply-rewrites", async (req, res) => {
  try {
    const resume = await Resume.findById(req.params.id);
    if (!resume) return res.status(404).json({ message: "Not found" });

    const latest = resume.versions[resume.versions.length - 1];
    const { indexes } = req.body || {};
    const rewrites = (latest.analysis.rewrites || []).filter(
      (_, i) => !indexes || indexes.includes(i)
    );

    let newText = latest.text;
    for (const r of rewrites) newText = newText.replace(r.original, r.improved);

    const analysis = await analyzeResume(newText);
    resume.versions.push({
      versionNumber: latest.versionNumber + 1,
      text: newText,
      source: "rewrite",
      analysis,
    });
    await resume.save();

    res.json(resume);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: err.message });
  }
});

export default router;
