import { GoogleGenAI } from "@google/genai";

let ai;
const client = () => (ai ??= new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY }));

export const analyzeResume = async (text) => {
  const prompt = `You are an expert ATS resume reviewer. Analyze the resume below.
Return ONLY valid JSON in exactly this shape:
{
  "atsScore": number (0-100),
  "breakdown": { "keywords": number, "formatting": number, "impact": number, "clarity": number },
  "issues": [ { "title": string, "severity": "high"|"medium"|"low", "fix": string } ],
  "strengths": [ string ],
  "rewrites": [ { "original": string, "improved": string, "reason": string } ],
  "keywords": { "present": [string], "missing": [string] }
}
Rules: exactly 5 issues, exactly 5 strengths, 5-10 rewrites of weak bullets.
"original" in each rewrite must be copied EXACTLY from the resume text.
All breakdown values are 0-100.

RESUME:
${text}`;

  const res = await client().models.generateContent({
    model: process.env.GEMINI_MODEL || "gemini-2.5-flash",
    contents: prompt,
    config: { responseMimeType: "application/json" },
  });

  const clean = res.text.replace(/```json|```/g, "").trim();
  const data = JSON.parse(clean);

  // defaults so the UI never crashes on missing fields
  data.breakdown ??= { keywords: 0, formatting: 0, impact: 0, clarity: 0 };
  data.issues ??= [];
  data.strengths ??= [];
  data.rewrites ??= [];
  data.keywords ??= { present: [], missing: [] };
  data.keywords.present ??= [];
  data.keywords.missing ??= [];
  return data;
};
